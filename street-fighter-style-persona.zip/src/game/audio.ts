export type Sound = 'punch' | 'kick' | 'special' | 'hit' | 'block' | 'round' | 'win';

export class ArenaAudio {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private muted = true;

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!muted && !this.context) {
      try {
        this.context = new AudioContext();
        this.master = this.context.createGain();
        this.master.gain.value = 0.22;
        this.master.connect(this.context.destination);
      } catch {
        return;
      }
    }
    if (!muted && this.context?.state === 'suspended') {
      void this.context.resume().catch(() => {});
    }
    if (this.master) this.master.gain.value = muted ? 0 : 0.22;
  }

  play(sound: Sound) {
    if (this.muted || !this.context || !this.master) return;
    const context = this.context;
    const now = context.currentTime;
    const gain = context.createGain();
    gain.connect(this.master);

    if (sound === 'punch' || sound === 'kick' || sound === 'block') {
      const length = sound === 'kick' ? 0.18 : 0.1;
      const buffer = context.createBuffer(1, context.sampleRate * length, context.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
      }
      const noise = context.createBufferSource();
      noise.buffer = buffer;
      const filter = context.createBiquadFilter();
      filter.type = sound === 'block' ? 'highpass' : 'lowpass';
      filter.frequency.value = sound === 'block' ? 1900 : 900;
      noise.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(0.45, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + length);
      noise.start(now);
      noise.stop(now + length);
      return;
    }

    const oscillator = context.createOscillator();
    oscillator.connect(gain);
    oscillator.type = sound === 'hit' ? 'triangle' : 'sawtooth';
    const duration = sound === 'win' ? 0.65 : sound === 'special' ? 0.4 : 0.2;
    const pitch = sound === 'hit' ? 100 : sound === 'special' ? 160 : sound === 'win' ? 330 : 440;
    oscillator.frequency.setValueAtTime(pitch, now);
    oscillator.frequency.exponentialRampToValueAtTime(
      sound === 'hit' ? 30 : sound === 'special' ? 650 : pitch * 1.5,
      now + duration,
    );
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(sound === 'hit' ? 0.7 : 0.13, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  dispose() {
    void this.context?.close().catch(() => {});
    this.context = null;
    this.master = null;
  }
}