export interface Sprite {
  image: HTMLCanvasElement;
  width: number;
  height: number;
  url: string;
}

export interface FighterAssets {
  kairo: Sprite;
  punch: Sprite;
  kick: Sprite;
  colossus: Sprite;
  colossusAttack: Sprite;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`Could not load ${src}`));
    image.src = src;
  });
}

async function loadSprite(src: string): Promise<Sprite> {
  const image = await loadImage(src);
  const source = document.createElement('canvas');
  source.width = image.naturalWidth;
  source.height = image.naturalHeight;
  const context = source.getContext('2d', { willReadFrequently: true });
  if (!context) throw new Error('Canvas is not supported in this browser.');
  context.drawImage(image, 0, 0);
  const frame = context.getImageData(0, 0, source.width, source.height);
  let left = source.width;
  let top = source.height;
  let right = 0;
  let bottom = 0;

  // Remove the chroma backdrop, including compression fringes, then trim the sprite.
  for (let y = 0; y < source.height; y++) {
    for (let x = 0; x < source.width; x++) {
      const i = (y * source.width + x) * 4;
      const r = frame.data[i];
      const g = frame.data[i + 1];
      const b = frame.data[i + 2];
      const spill = g - Math.max(r, b);
      if (g > 75 && spill > 30) {
        frame.data[i + 3] = 0;
      } else if (spill > 14 && g > 65) {
        frame.data[i + 1] = Math.max(r, b);
        frame.data[i + 3] = Math.round(255 * (1 - (spill - 14) / 17));
      }
      if (frame.data[i + 3] > 80) {
        left = Math.min(left, x);
        right = Math.max(right, x);
        top = Math.min(top, y);
        bottom = Math.max(bottom, y);
      }
    }
  }

  context.putImageData(frame, 0, 0);
  if (right <= left || bottom <= top) throw new Error('The fighter artwork is empty.');
  left = Math.max(0, left - 2);
  top = Math.max(0, top - 2);
  const cutout = document.createElement('canvas');
  cutout.width = Math.min(source.width - left, right - left + 4);
  cutout.height = Math.min(source.height - top, bottom - top + 4);
  cutout.getContext('2d')?.drawImage(
    source, left, top, cutout.width, cutout.height,
    0, 0, cutout.width, cutout.height,
  );
  return {
    image: cutout,
    width: cutout.width,
    height: cutout.height,
    url: cutout.toDataURL('image/png'),
  };
}

let assetsPromise: Promise<FighterAssets> | null = null;

export function loadFighterAssets(): Promise<FighterAssets> {
  if (!assetsPromise) {
    assetsPromise = Promise.all([
      loadSprite('/images/kairo-sprite.png'),
      loadSprite('/images/kairo-punch.png'),
      loadSprite('/images/kairo-kick.png'),
      loadSprite('/images/colossus-sprite.png'),
      loadSprite('/images/colossus-attack.png'),
    ]).then(([kairo, punch, kick, colossus, colossusAttack]) => ({
      kairo, punch, kick, colossus, colossusAttack,
    })).catch((error: unknown) => {
      assetsPromise = null;
      throw error;
    });
  }
  return assetsPromise;
}