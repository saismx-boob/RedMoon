import type { FighterAssets, Sprite } from './assets';
import type { Sound } from './audio';

export type Difficulty = 'easy' | 'normal' | 'hard';
export type Phase = 'ready' | 'countdown' | 'fighting' | 'paused' | 'roundEnd' | 'matchEnd';
export type Command = 'left' | 'right' | 'jump' | 'punch' | 'kick' | 'special' | 'block' | 'dash';
type Action = 'idle' | 'walk' | 'jump' | 'punch' | 'kick' | 'special' | 'block' | 'hurt' | 'defeated';
type Side = 'player' | 'enemy';

export interface GameSnapshot {
  phase: Phase;
  round: number;
  time: number;
  playerHealth: number;
  enemyHealth: number;
  playerEnergy: number;
  enemyEnergy: number;
  playerWins: number;
  enemyWins: number;
  combo: number;
  banner: string;
  winner: Side | null;
  training: boolean;
  difficulty: Difficulty;
}

export const INITIAL_SNAPSHOT: GameSnapshot = {
  phase: 'ready', round: 1, time: 99,
  playerHealth: 100, enemyHealth: 100,
  playerEnergy: 35, enemyEnergy: 20,
  playerWins: 0, enemyWins: 0, combo: 0,
  banner: '', winner: null, training: false, difficulty: 'normal',
};

interface Fighter {
  x: number;
  y: number;
  vx: number;
  vy: number;
  health: number;
  energy: number;
  facing: 1 | -1;
  action: Action;
  actionTime: number;
  actionAge: number;
  cooldown: number;
  hit: boolean;
  side: Side;
}

interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; total: number; size: number; color: string;
}

interface Projectile {
  x: number; y: number; vx: number; life: number; side: Side;
}

interface FloatingText {
  x: number; y: number; text: string; color: string; life: number;
}

const WIDTH = 1440;
const HEIGHT = 600;
const GROUND = 548;
const ATTACKS = {
  punch: { duration: 0.3, contact: 0.1, range: 212, damage: 9, cooldown: 0.35 },
  kick: { duration: 0.46, contact: 0.17, range: 280, damage: 15, cooldown: 0.6 },
  special: { duration: 0.58, contact: 0.16, range: 0, damage: 28, cooldown: 0.95 },
};

function fighter(side: Side): Fighter {
  return {
    x: side === 'player' ? 375 : 1055, y: 0, vx: 0, vy: 0,
    health: 100, energy: side === 'player' ? 35 : 20,
    facing: side === 'player' ? 1 : -1,
    action: 'idle', actionTime: 0, actionAge: 0,
    cooldown: 0, hit: false, side,
  };
}

export class FightEngine {
  private canvas: HTMLCanvasElement;
  private context: CanvasRenderingContext2D;
  private assets: FighterAssets;
  private onUpdate: (snapshot: GameSnapshot) => void;
  private onSound: (sound: Sound) => void;
  private player = fighter('player');
  private enemy = fighter('enemy');
  private phase: Phase = 'ready';
  private beforePause: Phase = 'fighting';
  private difficulty: Difficulty;
  private training = false;
  private round = 1;
  private time = 99;
  private playerWins = 0;
  private enemyWins = 0;
  private winner: Side | null = null;
  private countdown = 0;
  private combo = 0;
  private comboTime = 0;
  private banner = '';
  private bannerTime = 0;
  private aiTimer = 0;
  private input = new Set<Command>();
  private particles: Particle[] = [];
  private projectiles: Projectile[] = [];
  private texts: FloatingText[] = [];
  private shake = 0;
  private elapsed = 0;
  private lastTime = 0;
  private emitTime = 0;
  private lastSnapshot = '';
  private compact = false;
  private reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  private frame = 0;
  private running = true;
  private resizeObserver: ResizeObserver;

  constructor(
    canvas: HTMLCanvasElement,
    assets: FighterAssets,
    onUpdate: (snapshot: GameSnapshot) => void,
    onSound: (sound: Sound) => void,
    difficulty: Difficulty,
  ) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas is not supported in this browser.');
    this.context = context;
    this.assets = assets;
    this.onUpdate = onUpdate;
    this.onSound = onSound;
    this.difficulty = difficulty;
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(canvas);
    this.resize();
    this.emit();
    this.frame = requestAnimationFrame(this.tick);
  }

  private resize() {
    const bounds = this.canvas.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    this.compact = (this.canvas.parentElement?.clientWidth ?? bounds.width) <= 620 && !document.fullscreenElement;
    this.canvas.width = Math.max(1, Math.round(bounds.width * ratio));
    this.canvas.height = Math.max(1, Math.round(bounds.height * ratio));
  }

  private emit() {
    const next: GameSnapshot = {
      phase: this.phase, round: this.round, time: Math.max(0, Math.ceil(this.time)),
      playerHealth: Math.max(0, this.player.health),
      enemyHealth: Math.max(0, this.enemy.health),
      playerEnergy: this.player.energy, enemyEnergy: this.enemy.energy,
      playerWins: this.playerWins, enemyWins: this.enemyWins,
      combo: this.combo, banner: this.banner, winner: this.winner,
      training: this.training, difficulty: this.difficulty,
    };
    const signature = JSON.stringify(next);
    if (signature !== this.lastSnapshot) {
      this.lastSnapshot = signature;
      this.onUpdate(next);
    }
  }

  start() {
    if (this.phase === 'ready') {
      this.phase = this.training ? 'fighting' : 'countdown';
      this.countdown = 2;
      this.banner = this.training ? '' : `ROUND ${this.round}`;
      this.aiTimer = 1.1;
      this.onSound('round');
    } else if (this.phase === 'paused') {
      this.resume();
    } else if (this.phase === 'roundEnd') {
      this.nextRound();
    } else if (this.phase === 'matchEnd') {
      this.reset();
      this.start();
    }
    this.emit();
  }

  pause() {
    if (this.phase === 'fighting' || this.phase === 'countdown') {
      this.beforePause = this.phase;
      this.phase = 'paused';
      this.clearInput();
      this.emit();
    }
  }

  resume() {
    if (this.phase === 'paused') {
      this.phase = this.beforePause;
      this.emit();
    }
  }

  togglePause() {
    if (this.phase === 'paused') this.resume();
    else this.pause();
  }

  reset() {
    this.round = 1;
    this.playerWins = 0;
    this.enemyWins = 0;
    this.resetRound();
    this.phase = 'ready';
    this.emit();
  }

  private resetRound() {
    this.player = fighter('player');
    this.enemy = fighter('enemy');
    if (this.training) this.player.energy = 100;
    this.time = 99;
    this.winner = null;
    this.combo = 0;
    this.comboTime = 0;
    this.banner = '';
    this.bannerTime = 0;
    this.particles = [];
    this.projectiles = [];
    this.texts = [];
    this.shake = 0;
    this.clearInput();
  }

  private nextRound() {
    this.round++;
    this.resetRound();
    this.phase = 'ready';
    this.start();
  }

  setDifficulty(difficulty: Difficulty) {
    this.difficulty = difficulty;
    this.emit();
  }

  setTraining(training: boolean) {
    this.training = training;
    this.reset();
    if (training) this.start();
  }

  command(command: Command, pressed: boolean) {
    if (pressed) this.input.add(command);
    else this.input.delete(command);
    if (this.phase === 'fighting') this.controlPlayer();
  }

  clearInput() {
    this.input.clear();
  }

  private tick = (timestamp: number) => {
    if (!this.running) return;
    const dt = this.lastTime ? Math.min((timestamp - this.lastTime) / 1000, 0.04) : 0;
    this.lastTime = timestamp;
    this.elapsed += dt;
    if (this.phase !== 'paused') {
      if (this.phase === 'countdown') {
        this.countdown -= dt;
        this.banner = this.countdown > 0.75 ? `ROUND ${this.round}` : 'FIGHT!';
        if (this.countdown <= 0) {
          this.phase = 'fighting';
          this.banner = '';
        }
      }
      if (this.phase === 'fighting') this.updateFight(dt);
      this.updateEffects(dt);
    }
    this.draw();
    this.emitTime += dt;
    if (this.emitTime > 0.075) {
      this.emitTime = 0;
      this.emit();
    }
    this.frame = requestAnimationFrame(this.tick);
  };

  private updateFight(dt: number) {
    if (!this.training) this.time -= dt;
    this.comboTime -= dt;
    if (this.comboTime <= 0) this.combo = 0;
    this.bannerTime -= dt;
    if (this.bannerTime <= 0) this.banner = '';
    this.updateFighter(this.player, dt);
    this.updateFighter(this.enemy, dt);
    this.controlPlayer();
    if (!this.training) this.controlEnemy(dt);

    this.player.facing = this.player.x <= this.enemy.x ? 1 : -1;
    this.enemy.facing = this.enemy.x <= this.player.x ? 1 : -1;

    if (Math.abs(this.player.x - this.enemy.x) < 132 && Math.abs(this.player.y - this.enemy.y) < 85) {
      const center = (this.player.x + this.enemy.x) / 2;
      this.player.x = center - this.player.facing * 66;
      this.enemy.x = center + this.player.facing * 66;
    }

    this.checkAttack(this.player, this.enemy);
    this.checkAttack(this.enemy, this.player);

    for (const projectile of this.projectiles) {
      projectile.x += projectile.vx * dt;
      projectile.life -= dt;
      const target = projectile.side === 'player' ? this.enemy : this.player;
      const targetCenter = GROUND - target.y - (target.side === 'player' ? 150 : 185);
      if (Math.abs(projectile.x - target.x) < 90 && Math.abs(projectile.y - targetCenter) < 120) {
        this.hit(projectile.side === 'player' ? this.player : this.enemy, target, projectile.side === 'player' ? 28 : 18);
        projectile.life = 0;
      }
    }
    this.projectiles = this.projectiles.filter((p) => p.life > 0 && p.x > -100 && p.x < WIDTH + 100);

    if (this.training) {
      this.player.energy = 100;
      if (this.enemy.health <= 0) {
        this.enemy.health = 100;
        this.enemy.action = 'idle';
      }
    } else if (this.player.health <= 0 || this.enemy.health <= 0 || this.time <= 0) {
      this.finishRound();
    }
  }

  private updateFighter(f: Fighter, dt: number) {
    f.cooldown = Math.max(0, f.cooldown - dt);
    f.actionAge += dt;
    f.actionTime -= dt;
    if (f.actionTime <= 0 && !['idle', 'walk', 'jump', 'block', 'defeated'].includes(f.action)) {
      f.action = f.y > 0 ? 'jump' : 'idle';
    }
    if (f.y > 0 || f.vy > 0) {
      f.y += f.vy * dt;
      f.vy -= 1600 * dt;
      if (f.y <= 0) {
        f.y = 0;
        f.vy = 0;
        if (f.action === 'jump') f.action = 'idle';
        this.dust(f.x, 8);
      }
    }
    const left = this.compact ? (f.side === 'player' ? 315 : 375) : 105;
    const right = this.compact ? (f.side === 'player' ? 1125 : 1065) : WIDTH - 105;
    f.x = Math.max(left, Math.min(right, f.x + f.vx * dt));
    f.vx *= Math.pow(0.015, dt);
    f.energy = Math.min(100, f.energy + dt * 1.5);
  }

  private controlPlayer() {
    const p = this.player;
    if (['punch', 'kick', 'special', 'hurt', 'defeated'].includes(p.action)) return;
    if (this.input.has('block') && p.y === 0) {
      p.action = 'block';
      p.vx = 0;
      return;
    }
    const direction = Number(this.input.has('right')) - Number(this.input.has('left'));
    p.vx = direction * (this.input.has('dash') ? 565 : 345);
    p.action = p.y > 0 ? 'jump' : direction ? 'walk' : 'idle';
    if (this.input.has('jump') && p.y === 0) {
      p.vy = 690;
      p.y = 1;
      p.action = 'jump';
      this.input.delete('jump');
      this.dust(p.x, 10);
    }
    if (this.input.has('special')) {
      this.beginAttack(p, 'special');
      this.input.delete('special');
    } else if (this.input.has('kick')) {
      this.beginAttack(p, 'kick');
    } else if (this.input.has('punch')) {
      this.beginAttack(p, 'punch');
    }
  }

  private controlEnemy(dt: number) {
    const e = this.enemy;
    this.aiTimer -= dt;
    if (['punch', 'kick', 'special', 'hurt', 'defeated'].includes(e.action)) return;
    if (e.action === 'block' && e.actionTime > 0) return;
    const distance = Math.abs(e.x - this.player.x);
    const level = this.difficulty;
    if (distance > 225) {
      e.vx = e.facing * (level === 'easy' ? 100 : level === 'normal' ? 155 : 210);
      e.action = 'walk';
    } else {
      e.vx = 0;
      e.action = 'idle';
    }
    if (this.aiTimer <= 0) {
      const chance = Math.random();
      if (e.energy >= 75 && distance > 270 && level !== 'easy') {
        this.beginAttack(e, 'special');
      } else if (distance < 285) {
        if (chance < (level === 'easy' ? 0.08 : level === 'hard' ? 0.3 : 0.16)) {
          e.action = 'block';
          e.actionTime = 0.55;
        } else {
          this.beginAttack(e, chance > 0.65 ? 'kick' : 'punch');
        }
      }
      this.aiTimer = (level === 'easy' ? 1.7 : level === 'normal' ? 1.15 : 0.75) + Math.random() * 0.35;
    }
  }

  private beginAttack(f: Fighter, attack: 'punch' | 'kick' | 'special') {
    if (f.cooldown > 0) return;
    if (attack === 'special' && f.energy < 50) {
      if (f.side === 'player') {
        this.banner = 'BUILD YOUR SPIRIT';
        this.bannerTime = 1.3;
      }
      return;
    }
    const data = ATTACKS[attack];
    f.action = attack;
    f.actionTime = data.duration + (f.side === 'enemy' ? 0.16 : 0);
    f.actionAge = 0;
    f.cooldown = data.cooldown + (f.side === 'enemy' ? 0.25 : 0);
    f.hit = false;
    f.vx = attack === 'punch' ? f.facing * 160 : attack === 'kick' ? f.facing * 90 : 0;
    if (attack === 'special') f.energy -= 50;
    this.onSound(attack);
  }

  private checkAttack(attacker: Fighter, target: Fighter) {
    const action = attacker.action;
    if (action !== 'punch' && action !== 'kick' && action !== 'special') return;
    const data = ATTACKS[action];
    if (attacker.hit || attacker.actionAge < data.contact + (attacker.side === 'enemy' ? 0.18 : 0)) return;
    attacker.hit = true;
    if (action === 'special') {
      this.projectiles.push({
        x: attacker.x + attacker.facing * 110,
        y: GROUND - attacker.y - (attacker.side === 'player' ? 158 : 180),
        vx: attacker.facing * (attacker.side === 'player' ? 880 : 620),
        life: 2.2, side: attacker.side,
      });
      this.burst(attacker.x, GROUND - attacker.y - 150, 20, attacker.side === 'player' ? '#d5ff76' : '#ff7157');
      return;
    }
    const dx = target.x - attacker.x;
    if (Math.abs(dx) <= data.range && dx * attacker.facing > 0 && Math.abs(target.y - attacker.y) < 130) {
      const enemyDamage = this.difficulty === 'easy' ? 0.7 : this.difficulty === 'hard' ? 1.2 : 0.9;
      this.hit(attacker, target, data.damage * (attacker.side === 'enemy' ? enemyDamage : 1));
    }
  }

  private hit(attacker: Fighter, target: Fighter, damage: number) {
    const blocked = target.action === 'block';
    const applied = blocked ? Math.max(1, Math.round(damage * 0.15)) : Math.round(damage);
    target.health = Math.max(0, target.health - applied);
    target.energy = Math.min(100, target.energy + (blocked ? 12 : 7));
    attacker.energy = Math.min(100, attacker.energy + (blocked ? 4 : 12));
    const color = blocked ? '#e5eae2' : attacker.side === 'player' ? '#d5ff76' : '#ff7157';
    const x = target.x - attacker.facing * 48;
    const y = GROUND - target.y - (target.side === 'player' ? 170 : 200);
    this.burst(x, y, blocked ? 12 : 26, color);
    this.shake = blocked ? 2 : damage >= 20 ? 10 : 5;
    this.texts.push({ x, y: y - 25, text: blocked ? 'GUARD' : `${applied}`, color, life: 0.7 });
    if (!blocked) {
      target.action = 'hurt';
      target.actionTime = 0.22;
      target.vx = attacker.facing * (damage >= 20 ? 320 : 170);
      if (attacker.side === 'player') {
        this.combo++;
        this.comboTime = 2.2;
      }
    }
    this.onSound(blocked ? 'block' : 'hit');
  }

  private finishRound() {
    this.winner = this.player.health >= this.enemy.health ? 'player' : 'enemy';
    if (this.winner === 'player') {
      this.playerWins++;
      if (this.enemy.health <= 0) this.enemy.action = 'defeated';
    } else {
      this.enemyWins++;
      if (this.player.health <= 0) this.player.action = 'defeated';
    }
    this.phase = this.playerWins >= 2 || this.enemyWins >= 2 ? 'matchEnd' : 'roundEnd';
    this.banner = '';
    this.player.vx = 0;
    this.enemy.vx = 0;
    this.clearInput();
    this.onSound('win');
    this.emit();
  }

  private burst(x: number, y: number, count: number, color: string) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 80 + Math.random() * 330;
      const life = 0.18 + Math.random() * 0.35;
      this.particles.push({
        x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
        life, total: life, size: 1.5 + Math.random() * 3, color,
      });
    }
  }

  private dust(x: number, count: number) {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x, y: GROUND - 3, vx: (Math.random() - 0.5) * 180,
        vy: -Math.random() * 70, life: 0.4, total: 0.4,
        size: 3 + Math.random() * 7, color: '#a29a84',
      });
    }
  }

  private updateEffects(dt: number) {
    this.shake = Math.max(0, this.shake - dt * 25);
    for (const p of this.particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 350 * dt;
      p.life -= dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);
    for (const text of this.texts) {
      text.y -= dt * 48;
      text.life -= dt;
    }
    this.texts = this.texts.filter((t) => t.life > 0);
  }

  private draw() {
    const ctx = this.context;
    ctx.setTransform(this.canvas.width / WIDTH, 0, 0, this.canvas.height / HEIGHT, 0, 0);
    ctx.clearRect(0, 0, WIDTH, HEIGHT);
    ctx.save();
    if (this.shake > 0 && !this.reducedMotion) ctx.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);

    // Slow drifting embers give the arena life without distracting from the fighters.
    for (let i = 0; i < (this.reducedMotion ? 0 : 22); i++) {
      const x = (i * 139.3 + Math.sin(this.elapsed * 0.27 + i) * 26) % WIDTH;
      const y = HEIGHT - ((this.elapsed * (17 + i % 4 * 8) + i * 47) % HEIGHT);
      ctx.globalAlpha = 0.18 + Math.sin(this.elapsed + i) ** 2 * 0.35;
      ctx.fillStyle = i % 3 === 0 ? '#ffd09b' : '#ef7053';
      ctx.fillRect(x, y, i % 3 === 0 ? 2.5 : 1.5, 3);
    }
    ctx.globalAlpha = 1;
    this.drawFighter(this.player);
    this.drawFighter(this.enemy);

    for (const projectile of this.projectiles) {
      const color = projectile.side === 'player' ? '#d5ff76' : '#ff7355';
      const direction = Math.sign(projectile.vx);
      ctx.save();
      const glow = ctx.createRadialGradient(projectile.x, projectile.y, 2, projectile.x, projectile.y, 66);
      glow.addColorStop(0, '#fff9d3');
      glow.addColorStop(0.25, color);
      glow.addColorStop(1, 'transparent');
      ctx.fillStyle = glow;
      ctx.fillRect(projectile.x - 70, projectile.y - 70, 140, 140);
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      for (let i = 0; i < 4; i++) {
        ctx.globalAlpha = 1 - i * 0.2;
        ctx.beginPath();
        ctx.ellipse(projectile.x - direction * i * 17, projectile.y, 15 + i * 2, 30 - i * 4, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    for (const p of this.particles) {
      ctx.globalAlpha = Math.min(1, p.life / p.total);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
    for (const text of this.texts) {
      ctx.globalAlpha = Math.min(1, text.life * 3);
      ctx.fillStyle = text.color;
      ctx.font = text.text === 'GUARD' ? '600 16px monospace' : 'italic 800 28px "Barlow Condensed", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(text.text, text.x, text.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  private drawFighter(f: Fighter) {
    const ctx = this.context;
    const isPlayer = f.side === 'player';
    let sprite: Sprite = isPlayer ? this.assets.kairo : this.assets.colossus;
    if (isPlayer && (f.action === 'punch' || f.action === 'special')) sprite = this.assets.punch;
    if (isPlayer && f.action === 'kick') sprite = this.assets.kick;
    if (!isPlayer && ['punch', 'kick', 'special'].includes(f.action)) sprite = this.assets.colossusAttack;
    const breathing = this.reducedMotion ? 0 : Math.sin(this.elapsed * (isPlayer ? 2.5 : 1.7) + (isPlayer ? 0 : 2));
    const walk = f.action === 'walk' ? Math.sin(this.elapsed * 13) * 4 : 0;
    let height = (isPlayer ? 333 : 421) + breathing * 2 + walk;
    if (f.action === 'block') height *= 0.88;
    const width = sprite.width / sprite.height * height;

    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = '#060707';
    ctx.beginPath();
    ctx.ellipse(f.x, GROUND + 1, (isPlayer ? 95 : 133) * (1 - f.y / 500), 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(f.x, GROUND - f.y);
    const flipped = isPlayer ? f.facing === -1 : f.facing === 1;
    if (flipped) ctx.scale(-1, 1);
    if (f.action === 'hurt') {
      ctx.rotate((isPlayer ? -1 : 1) * 0.06);
      ctx.filter = 'brightness(1.7)';
    } else if (f.action === 'defeated') {
      ctx.globalAlpha = 0.58;
      ctx.rotate((isPlayer ? -1 : 1) * 0.22);
      ctx.filter = 'grayscale(0.7)';
    } else {
      ctx.filter = isPlayer ? 'drop-shadow(2px 0 3px rgba(245, 117, 64, 0.22))' : 'drop-shadow(0 0 6px rgba(233, 65, 40, 0.25))';
    }
    ctx.drawImage(sprite.image, -width / 2, -height, width, height);
    ctx.filter = 'none';

    if (f.action === 'block') {
      ctx.strokeStyle = isPlayer ? 'rgba(215,255,128,0.65)' : 'rgba(255,125,90,0.65)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(isPlayer ? 58 : -88, -height * 0.52, 42, 85, 0, -Math.PI * 0.5, Math.PI * 0.5);
      ctx.stroke();
    }
    ctx.restore();
  }

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.frame);
    this.resizeObserver.disconnect();
    this.clearInput();
  }
}