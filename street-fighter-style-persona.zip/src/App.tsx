import { useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, MotionConfig, motion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, ArrowUp, ArrowUpRight, Check, ChevronDown,
  Crosshair, Gamepad2, Maximize2, Minimize2, Pause, Play, RotateCcw,
  Shield, Swords, Volume2, VolumeX, X, Zap,
} from 'lucide-react';
import { loadFighterAssets } from './game/assets';
import type { FighterAssets } from './game/assets';
import { ArenaAudio } from './game/audio';
import { FightEngine, INITIAL_SNAPSHOT } from './game/engine';
import type { Command, Difficulty, GameSnapshot } from './game/engine';

type ModalName = 'fighters' | 'controls' | null;

const KEY_BINDINGS: Record<string, Command> = {
  KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right',
  KeyW: 'jump', ArrowUp: 'jump', KeyS: 'block', ArrowDown: 'block',
  KeyJ: 'punch', KeyK: 'kick', KeyL: 'special', ShiftLeft: 'dash', ShiftRight: 'dash',
};

function getSavedDifficulty(): Difficulty {
  try {
    const saved = localStorage.getItem('kairo-difficulty');
    if (saved === 'easy' || saved === 'normal' || saved === 'hard') return saved;
  } catch { /* Local play also works when browser storage is unavailable. */ }
  return 'normal';
}

function Brand({ onClick }: { onClick: () => void }) {
  return (
    <button className="brand" onClick={onClick} aria-label="Kairo, return to arena">
      <svg className="brand-symbol" viewBox="0 0 36 42" fill="none" aria-hidden="true">
        <path d="M11 3H19L9 39H1L11 3Z" fill="currentColor" />
        <path d="M26 3H36L19 21L29 39H19L9 21L26 3Z" fill="currentColor" />
      </svg>
      <span className="brand-type">KAIRO<span>THE LAST STAND</span></span>
    </button>
  );
}

function RoundPips({ wins }: { wins: number }) {
  return <span className="round-pips" aria-label={`${wins} rounds won`}>{[0, 1].map((index) => <i key={index} className={index < wins ? 'won' : ''} />)}</span>;
}

function FighterHud({ enemy, health, wins }: { enemy?: boolean; health: number; wins: number }) {
  return (
    <div className={`fighter-hud ${enemy ? 'enemy-hud' : 'player-hud'}`}>
      <div className="hud-avatar"><img src={`/images/${enemy ? 'colossus' : 'kairo'}-portrait.jpg`} alt="" /></div>
      <div className="hud-details">
        <div className="hud-name-row"><h2>{enemy ? 'THE COLOSSUS' : 'KAIRO'}</h2><span className="player-tag">{enemy ? 'CPU' : 'P1'}</span></div>
        <div className="health-track" role="progressbar" aria-label={`${enemy ? 'Colossus' : 'Kairo'} health`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(health)}>
          <div className="health-fill" style={{ width: `${health}%` }} />
        </div>
        <div className="hud-name-bottom"><span>{enemy ? 'ANCIENT TITAN' : 'THE RIFTBORN'}</span><RoundPips wins={wins} /></div>
      </div>
    </div>
  );
}

function EnergyMeter({ value, enemy }: { value: number; enemy?: boolean }) {
  return (
    <div className={`energy-meter ${enemy ? 'enemy-energy' : ''} ${value >= 50 ? 'charged' : ''}`}>
      <div className="energy-label"><span>{enemy ? 'RAGE' : 'SPIRIT'}</span><span>{!enemy && value >= 50 ? 'SPECIAL READY' : `${Math.floor(value)} / 100`}</span></div>
      <div className="energy-segments" aria-label={`${enemy ? 'Rage' : 'Spirit'}: ${Math.floor(value)} percent`}>
        {[0, 1, 2, 3, 4].map((segment) => <span key={segment}><i style={{ width: `${Math.min(100, Math.max(0, (value - segment * 20) * 5))}%` }} /></span>)}
      </div>
    </div>
  );
}

function Dialog({ title, onClose, children, className = '' }: { title: string; onClose: () => void; children: ReactNode; className?: string }) {
  const dialogRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const dialog = dialogRef.current;
    const focusable = () => Array.from(dialog?.querySelectorAll<HTMLElement>('button:not(:disabled), a[href], select, [tabindex="0"]') ?? []);
    focusable()[0]?.focus();
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); onClose(); }
      if (event.key === 'Tab') {
        const elements = focusable();
        const first = elements[0];
        const last = elements[elements.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    dialog?.addEventListener('keydown', handleKey);
    return () => { dialog?.removeEventListener('keydown', handleKey); previous?.focus({ preventScroll: true }); };
  }, [onClose]);
  return (
    <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.section ref={dialogRef} className={`modal ${className}`} role="dialog" aria-modal="true" aria-label={title} initial={{ opacity: 0, y: 24, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.98 }} transition={{ duration: 0.24 }} onClick={(event) => event.stopPropagation()}>
        <div className="modal-topline"><span>{title}</span><button className="icon-button" aria-label="Close dialog" onClick={onClose}><X size={20} /></button></div>
        {children}
      </motion.section>
    </motion.div>
  );
}

function FightersDialog({ assets, onClose, onFight }: { assets: FighterAssets | null; onClose: () => void; onFight: () => void }) {
  const [selected, setSelected] = useState<'kairo' | 'colossus'>('kairo');
  const [move, setMove] = useState<'idle' | 'punch' | 'kick' | 'special'>('idle');
  const isKairo = selected === 'kairo';
  useEffect(() => {
    if (move === 'idle') return;
    const timer = window.setTimeout(() => setMove('idle'), 950);
    return () => window.clearTimeout(timer);
  }, [move]);
  const sprite = isKairo ? move === 'kick' ? assets?.kick : move === 'idle' ? assets?.kairo : assets?.punch : move === 'idle' ? assets?.colossus : assets?.colossusAttack;
  return (
    <Dialog title="FIGHTER ARCHIVE / 02" onClose={onClose} className="fighters-modal">
      <div className="fighter-tabs" role="tablist" aria-label="Fighters">
        <button role="tab" id="kairo-tab" aria-selected={isKairo} aria-controls="fighter-profile" className={isKairo ? 'active' : ''} onClick={() => { setSelected('kairo'); setMove('idle'); }}><img src="/images/kairo-portrait.jpg" alt="" /><span>KAIRO<small>THE RIFTBORN</small></span><span className="tab-type">P1</span></button>
        <button role="tab" id="colossus-tab" aria-selected={!isKairo} aria-controls="fighter-profile" className={!isKairo ? 'active enemy-tab' : ''} onClick={() => { setSelected('colossus'); setMove('idle'); }}><img src="/images/colossus-portrait.jpg" alt="" /><span>THE COLOSSUS<small>ANCIENT TITAN</small></span><span className="tab-type">CPU</span></button>
      </div>
      <div className={`fighter-profile ${isKairo ? '' : 'colossus-profile'}`} id="fighter-profile" role="tabpanel" aria-labelledby={isKairo ? 'kairo-tab' : 'colossus-tab'}>
        <div className="profile-art">
          <span className="profile-number" aria-hidden="true">{isKairo ? '01' : '02'}</span>
          <AnimatePresence mode="wait"><motion.img key={`${selected}-${move}`} src={sprite?.url ?? `/images/${selected}-portrait.jpg`} className={`${sprite ? 'profile-sprite' : 'profile-portrait'} ${move === 'special' ? 'special-preview' : ''}`} alt={isKairo ? 'Kairo, a black-haired fighter in a black jacket with bandaged forearms' : 'The Colossus, a massive obsidian golem with glowing magma cracks'} initial={{ opacity: 0, x: isKairo ? -12 : 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }} /></AnimatePresence>
          <span className="profile-art-caption">{move === 'idle' ? 'SELECT A MOVE TO PREVIEW' : 'COMBAT PREVIEW'}</span>
        </div>
        <div className="profile-copy">
          <span className="eyebrow">{isKairo ? 'HUMAN / 17 YEARS / 1.78 M' : 'PRIMORDIAL / AGE UNKNOWN'}</span>
          <h2>{isKairo ? 'KAIRO' : <>THE<br />COLOSSUS</>}</h2>
          <h3>{isKairo ? 'CALM MIND. RELENTLESS FISTS.' : 'BORN IN FIRE. BUILT TO DESTROY.'}</h3>
          <p>{isKairo ? 'A quiet fighter with a troubled past. He trusts slowly, hates injustice, and carries more than the scars you can see. His greatest battle? To stop running.' : 'An ancient force awakened beneath the Ashen Ruins. Forged from black stone and living magma, the Colossus knows only one thing: nothing stands in its way.'}</p>
          <div className="profile-detail"><span>FIGHTING STYLE</span><strong>{isKairo ? 'Close-range rushdown' : 'Heavy-hitting power'}</strong></div>
          <div className="profile-moves">
            <span className="section-label">SIGNATURE MOVES</span>
            {(isKairo ? [
              { key: 'J', name: 'Iron Fist', action: 'punch' as const }, { key: 'K', name: 'Rising Heel', action: 'kick' as const }, { key: 'L', name: 'Rift Strike', action: 'special' as const },
            ] : [
              { key: '01', name: 'Basalt Fist', action: 'punch' as const }, { key: '02', name: 'Seismic Slam', action: 'kick' as const }, { key: '03', name: 'Magma Surge', action: 'special' as const },
            ]).map((item) => <button key={item.key} className={move === item.action ? 'selected' : ''} onClick={() => setMove(item.action)}><kbd>{item.key}</kbd><span>{item.name}</span><Play size={12} /></button>)}
          </div>
          <button className="primary-button profile-cta" onClick={onFight}>{isKairo ? 'PLAY AS KAIRO' : 'CHALLENGE THE COLOSSUS'}<ArrowRight size={18} /></button>
        </div>
      </div>
    </Dialog>
  );
}

function ControlsDialog({ onClose, onPractice }: { onClose: () => void; onPractice: () => void }) {
  return (
    <Dialog title="THE FIELD GUIDE / 01" onClose={onClose} className="controls-modal">
      <span className="eyebrow">EASY TO LEARN. HARD TO MASTER.</span><h2 className="modal-heading">MAKE YOUR MOVE.</h2><p className="modal-intro">Get close. Find an opening. Make every hit count.</p>
      <div className="controls-columns">
        <div>
          <h3><Gamepad2 size={17} />MOVEMENT</h3>
          <div className="guide-row"><span>Move left / right<small>Arrow keys work, too.</small></span><span className="guide-keys"><kbd>A</kbd><kbd>D</kbd></span></div>
          <div className="guide-row"><span>Jump<small>Go over your opponent or dodge a strike.</small></span><span className="guide-keys"><kbd>W</kbd><kbd className="wide-key">SPACE</kbd></span></div>
          <div className="guide-row"><span>Dash<small>Hold while moving to close the gap.</small></span><kbd className="wide-key">SHIFT</kbd></div>
          <div className="guide-row"><span>Block<small>Hold to reduce incoming damage.</small></span><kbd>S</kbd></div>
        </div>
        <div>
          <h3><Swords size={17} />COMBAT</h3>
          <div className="guide-row"><span>Iron Fist<small>Fast strike. Great for starting a combo.</small></span><kbd>J</kbd></div>
          <div className="guide-row"><span>Rising Heel<small>More reach. More damage.</small></span><kbd>K</kbd></div>
          <div className="guide-row"><span>Rift Strike<small>A ranged attack. Requires 50 spirit.</small></span><kbd>L</kbd></div>
          <div className="guide-row"><span>Pause / restart<small>Take a breath. Or take another shot.</small></span><span className="guide-keys"><kbd className="wide-key">ESC</kbd><kbd>R</kbd></span></div>
        </div>
      </div>
      <div className="guide-tip"><Zap size={19} /><p><strong>BREAK THE STONE.</strong> Land punches and kicks to build spirit. Chain <kbd>J</kbd>, <kbd>K</kbd>, then <kbd>L</kbd> for a devastating finish.</p></div>
      <div className="guide-footer"><span><Check size={15} /> First to win two rounds takes the match.</span><button className="primary-button" onClick={onPractice}>TRY PRACTICE MODE<ArrowRight size={18} /></button></div>
    </Dialog>
  );
}

function TouchKey({ command, children, onCommand, className = '', label }: { command: Command; children: ReactNode; onCommand: (command: Command, down: boolean) => void; className?: string; label: string }) {
  return (
    <button className={`key-button ${className}`} aria-label={label}
      onPointerDown={(event) => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); onCommand(command, true); }}
      onPointerUp={() => onCommand(command, false)} onPointerCancel={() => onCommand(command, false)} onLostPointerCapture={() => onCommand(command, false)}
      onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onCommand(command, true); } }}
      onKeyUp={(event) => { if (event.key === 'Enter' || event.key === ' ') onCommand(command, false); }} onBlur={() => onCommand(command, false)}
    >{children}</button>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameContainerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<FightEngine | null>(null);
  const audioRef = useRef<ArenaAudio | null>(null);
  const wasPlayingRef = useRef(false);
  const [snapshot, setSnapshot] = useState<GameSnapshot>(INITIAL_SNAPSHOT);
  const snapshotRef = useRef(snapshot);
  snapshotRef.current = snapshot;
  const [assets, setAssets] = useState<FighterAssets | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [retry, setRetry] = useState(0);
  const [difficulty, setDifficulty] = useState<Difficulty>(getSavedDifficulty);
  const difficultyRef = useRef(difficulty);
  const [muted, setMuted] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);
  const [modal, setModal] = useState<ModalName>(null);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    const audio = new ArenaAudio();
    audioRef.current = audio;
    return () => { audio.dispose(); audioRef.current = null; };
  }, []);

  useEffect(() => {
    let active = true;
    setLoaded(false);
    setLoadError(false);
    void loadFighterAssets().then((loadedAssets) => {
      if (!active || !canvasRef.current) return;
      setAssets(loadedAssets);
      engineRef.current = new FightEngine(canvasRef.current, loadedAssets, (next) => { if (active) setSnapshot(next); }, (sound) => audioRef.current?.play(sound), difficultyRef.current);
      setLoaded(true);
    }).catch(() => { if (active) setLoadError(true); });
    return () => { active = false; engineRef.current?.dispose(); engineRef.current = null; };
  }, [retry]);

  const closeModal = useCallback(() => {
    setModal(null);
    if (wasPlayingRef.current) engineRef.current?.resume();
    wasPlayingRef.current = false;
  }, []);

  const openModal = useCallback((name: Exclude<ModalName, null>) => {
    const phase = snapshotRef.current.phase;
    wasPlayingRef.current = phase === 'fighting' || phase === 'countdown';
    engineRef.current?.pause();
    engineRef.current?.clearInput();
    setModal(name);
  }, []);

  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (modal || event.ctrlKey || event.metaKey || event.altKey) return;
      const target = event.target as HTMLElement;
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(target.tagName)) return;
      if (target.closest('button') && (event.code === 'Space' || event.code === 'Enter')) return;
      const engine = engineRef.current;
      if (!engine) return;
      if (event.code === 'Space' || event.code === 'Enter') {
        event.preventDefault();
        if (event.repeat) return;
        if (snapshotRef.current.phase === 'fighting') { if (event.code === 'Space') engine.command('jump', true); }
        else if (snapshotRef.current.phase !== 'countdown') engine.start();
      } else if (event.code === 'Escape' || event.code === 'KeyP') {
        event.preventDefault();
        if (!event.repeat) engine.togglePause();
      } else if (event.code === 'KeyR') {
        if (!event.repeat) engine.reset();
      } else if (KEY_BINDINGS[event.code]) {
        event.preventDefault();
        engine.command(KEY_BINDINGS[event.code], true);
      }
    };
    const keyup = (event: KeyboardEvent) => {
      const command = KEY_BINDINGS[event.code] ?? (event.code === 'Space' ? 'jump' : null);
      if (command) engineRef.current?.command(command, false);
    };
    const blur = () => { engineRef.current?.clearInput(); engineRef.current?.pause(); };
    const visibility = () => { if (document.hidden) blur(); };
    window.addEventListener('keydown', keydown);
    window.addEventListener('keyup', keyup);
    window.addEventListener('blur', blur);
    document.addEventListener('visibilitychange', visibility);
    return () => { window.removeEventListener('keydown', keydown); window.removeEventListener('keyup', keyup); window.removeEventListener('blur', blur); document.removeEventListener('visibilitychange', visibility); };
  }, [modal]);

  useEffect(() => {
    const update = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', update);
    return () => document.removeEventListener('fullscreenchange', update);
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 3500);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const handleDifficulty = (next: Difficulty) => {
    setDifficulty(next);
    difficultyRef.current = next;
    engineRef.current?.setDifficulty(next);
    try { localStorage.setItem('kairo-difficulty', next); } catch { /* Optional preference. */ }
  };
  const toggleSound = () => { audioRef.current?.setMuted(!muted); if (muted) audioRef.current?.play('round'); setMuted(!muted); };
  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (gameContainerRef.current?.requestFullscreen) await gameContainerRef.current.requestFullscreen();
      else setNotice('Fullscreen is not supported in this browser.');
    } catch { setNotice('Your browser could not enter fullscreen.'); }
  };
  const primaryAction = () => {
    if (snapshot.phase === 'fighting' || snapshot.phase === 'countdown') engineRef.current?.pause();
    else engineRef.current?.start();
    canvasRef.current?.focus({ preventScroll: true });
  };
  const togglePractice = () => {
    engineRef.current?.setTraining(!snapshot.training);
    canvasRef.current?.focus({ preventScroll: true });
  };
  const restart = () => {
    engineRef.current?.reset();
    canvasRef.current?.focus({ preventScroll: true });
  };
  const practice = () => { closeModal(); engineRef.current?.setTraining(true); canvasRef.current?.focus({ preventScroll: true }); };
  const fightFromProfile = () => { closeModal(); engineRef.current?.setTraining(false); engineRef.current?.start(); canvasRef.current?.focus({ preventScroll: true }); };
  const onCommand = (command: Command, down: boolean) => engineRef.current?.command(command, down);
  const isActive = snapshot.phase === 'fighting' || snapshot.phase === 'countdown';
  const primaryLabel = isActive ? 'PAUSE FIGHT' : snapshot.phase === 'paused' ? 'RESUME FIGHT' : snapshot.phase === 'roundEnd' ? 'NEXT ROUND' : snapshot.phase === 'matchEnd' ? 'FIGHT AGAIN' : 'START FIGHT';
  const statusLabel = snapshot.training ? 'PRACTICE MODE' : snapshot.phase === 'ready' ? 'READY TO FIGHT' : snapshot.phase === 'paused' ? 'TAKE A BREATH' : snapshot.phase === 'roundEnd' ? 'ROUND COMPLETE' : snapshot.phase === 'matchEnd' ? 'MATCH COMPLETE' : `ROUND ${String(snapshot.round).padStart(2, '0')} IN PROGRESS`;
  const isResult = snapshot.phase === 'roundEnd' || snapshot.phase === 'matchEnd';
  const overlayRoot = fullscreen && gameContainerRef.current ? gameContainerRef.current : document.body;

  return (
    <MotionConfig reducedMotion="user">
    <div className="app">
      <header className="site-header">
        <div className="nav-inner">
          <Brand onClick={() => { closeModal(); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />
          <nav className="main-nav" aria-label="Main navigation">
            <button className={!modal ? 'active' : ''} onClick={closeModal}><span>01</span>ARENA</button>
            <button className={modal === 'fighters' ? 'active' : ''} onClick={() => openModal('fighters')}><span>02</span>FIGHTERS</button>
            <button className={modal === 'controls' ? 'active' : ''} onClick={() => openModal('controls')}><span>03</span>HOW TO PLAY</button>
          </nav>
          <div className="nav-tools">
            <span className="local-play"><i />LOCAL ARCADE</span>
            <button className="icon-button sound-button" onClick={toggleSound} aria-label={muted ? 'Turn sound on' : 'Mute sound'} aria-pressed={!muted} title={muted ? 'Sound off' : 'Sound on'}>{muted ? <VolumeX size={19} /> : <Volume2 size={19} />}</button>
            <button className="icon-button" onClick={() => void toggleFullscreen()} aria-label={fullscreen ? 'Exit fullscreen' : 'Enter fullscreen'} title="Fullscreen">{fullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}</button>
          </div>
        </div>
      </header>
      <main className="main-content">
        <motion.div className="arena-heading" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.55 }}>
          <div className="heading-copy"><span className="eyebrow">A 2D ARCADE FIGHTER</span><h1>KAIRO<span className="heading-slash">/</span><span className="heading-subtitle">THE LAST STAND</span><span className="title-period">.</span></h1><p>Stand against the darkness. Make every hit count.</p></div>
          <div className="arena-config">
            <div className="stage-info"><Crosshair size={22} /><div><span>STAGE 01</span><strong>ASHEN RUINS</strong></div></div>
            <div className="difficulty-control"><label htmlFor="difficulty">CPU LEVEL</label><div className="difficulty-select"><select id="difficulty" value={difficulty} onChange={(event) => handleDifficulty(event.target.value as Difficulty)}><option value="easy">Easy</option><option value="normal">Normal</option><option value="hard">Hard</option></select><ChevronDown size={14} /></div></div>
          </div>
        </motion.div>
        <motion.div className="game-container" ref={gameContainerRef} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.65, delay: 0.12 }}>
          <section className={`game-shell ${snapshot.phase === 'paused' ? 'is-paused' : ''}`} aria-label="Fighting arena">
            <div className="arena">
              <div className="arena-vignette" />
              <canvas ref={canvasRef} className="battle-canvas" tabIndex={0} aria-label="Kairo versus the Colossus. Move with A and D, jump with W, punch with J, kick with K, and use a special with L.">Your browser must support canvas to play this game.</canvas>
              <div className="fight-hud"><FighterHud health={snapshot.playerHealth} wins={snapshot.playerWins} /><div className="round-timer"><span>{snapshot.training ? 'PRACTICE' : `ROUND ${String(snapshot.round).padStart(2, '0')}`}</span><strong>{snapshot.training ? '--' : String(snapshot.time).padStart(2, '0')}</strong><i>{snapshot.training ? 'FREE TRAINING' : 'BEST OF 3'}</i></div><FighterHud enemy health={snapshot.enemyHealth} wins={snapshot.enemyWins} /></div>
              <EnergyMeter value={snapshot.playerEnergy} /><EnergyMeter enemy value={snapshot.enemyEnergy} />
              <div className="stage-caption"><span />THE ASHEN RUINS<span /></div>
              <AnimatePresence mode="wait">
                {!loaded ? <motion.div className="arena-loader" key="loading" exit={{ opacity: 0 }}>{loadError ? <><span>THE ARENA COULD NOT LOAD.</span><button className="text-button" onClick={() => setRetry(retry + 1)}>TRY AGAIN<RotateCcw size={14} /></button></> : <><div className="loading-ring" /><span>PREPARING THE ARENA</span></>}</motion.div>
                  : snapshot.phase === 'ready' ? <motion.div className="versus-mark" key="ready" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.15 }} transition={{ duration: 0.4 }}><span>ONE LAST STAND</span><strong>VS<span>.</span></strong><i>FACE YOUR FEAR</i></motion.div>
                  : snapshot.phase === 'countdown' ? <motion.div className="combat-overlay countdown-overlay" key={snapshot.banner} initial={{ opacity: 0, scale: 1.25 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.85 }} transition={{ duration: 0.2 }}><strong>{snapshot.banner}</strong></motion.div>
                  : snapshot.phase === 'paused' ? <motion.div className="combat-overlay pause-overlay" key="paused" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><span className="eyebrow">THE FIGHT CAN WAIT.</span><strong>PAUSED<span>.</span></strong><button className="overlay-resume" onClick={primaryAction}><Play size={16} fill="currentColor" />BACK TO THE FIGHT</button></motion.div>
                  : isResult ? <motion.div className={`combat-overlay result-overlay ${snapshot.winner === 'enemy' ? 'loss' : ''}`} key="result" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}><span className="eyebrow">{snapshot.phase === 'matchEnd' ? 'THE FINAL VERDICT' : `ROUND ${snapshot.round} COMPLETE`}</span><strong>{snapshot.winner === 'player' ? snapshot.phase === 'matchEnd' ? 'KAIRO WINS.' : 'ROUND WON.' : snapshot.phase === 'matchEnd' ? 'DEFEATED.' : 'ROUND LOST.'}</strong><p>{snapshot.winner === 'player' ? 'Even mountains can fall.' : 'Get back up. Your story is not over.'}</p><button className="overlay-resume" onClick={primaryAction}>{snapshot.phase === 'matchEnd' ? 'FIGHT AGAIN' : 'NEXT ROUND'}<ArrowRight size={17} /></button></motion.div> : null}
              </AnimatePresence>
              <AnimatePresence>
                {snapshot.combo >= 2 && snapshot.phase === 'fighting' && <motion.div className="combo-counter" initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}><strong>{snapshot.combo}</strong><span>HIT<br />COMBO</span></motion.div>}
                {snapshot.banner && snapshot.phase === 'fighting' && <motion.div className="combat-notice" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>{snapshot.banner}</motion.div>}
              </AnimatePresence>
            </div>
            <div className="game-toolbar">
              <div className="game-status"><i className={isActive ? 'live' : ''} /><div><strong>{statusLabel}</strong><span>{snapshot.training ? 'Unlimited spirit. A worthy training dummy.' : 'YOU VS CPU / FIRST TO TWO WINS'}</span></div></div>
              <div className="start-hint"><kbd>{snapshot.phase === 'ready' ? 'SPACE' : snapshot.phase === 'paused' ? 'ESC' : isResult ? 'ENTER' : 'ESC'}</kbd><span>{snapshot.phase === 'ready' ? 'to enter the arena' : snapshot.phase === 'paused' ? 'to resume' : isResult ? 'to keep fighting' : 'to pause'}</span></div>
              <div className="toolbar-actions">
                <button className={`practice-button ${snapshot.training ? 'active' : ''}`} disabled={!loaded} onClick={togglePractice}><Crosshair size={16} /><span>{snapshot.training ? 'EXIT PRACTICE' : 'PRACTICE'}</span></button>
                <button className="icon-button restart-button" disabled={!loaded} onClick={restart} aria-label="Restart match" title="Restart match (R)"><RotateCcw size={17} /></button>
                <button className="primary-button fight-button" disabled={!loaded} onClick={primaryAction}>{primaryLabel}{isActive ? <Pause size={17} fill="currentColor" /> : snapshot.phase === 'paused' ? <Play size={17} fill="currentColor" /> : <ArrowRight size={20} />}</button>
              </div>
            </div>
          </section>
          <div className="quick-controls" aria-label="Game controls">
            <div className="controls-label"><span>YOUR NEXT MOVE</span><strong>MAKE IT COUNT.</strong></div>
            <div className="quick-control move-control"><div className="control-keys"><TouchKey command="left" label="Move left (A)" onCommand={onCommand}><span className="desktop-key">A</span><ArrowLeft className="mobile-key" size={18} /></TouchKey><TouchKey command="right" label="Move right (D)" onCommand={onCommand}><span className="desktop-key">D</span><ArrowRight className="mobile-key" size={18} /></TouchKey></div><span>Move</span></div>
            <div className="quick-control"><TouchKey command="jump" label="Jump (W)" onCommand={onCommand}><span className="desktop-key">W</span><ArrowUp className="mobile-key" size={18} /></TouchKey><span>Jump</span></div>
            <div className="quick-control"><TouchKey command="punch" label="Punch (J)" onCommand={onCommand}>J</TouchKey><span>Punch</span></div>
            <div className="quick-control"><TouchKey command="kick" label="Kick (K)" onCommand={onCommand}>K</TouchKey><span>Kick</span></div>
            <div className="quick-control"><TouchKey command="block" label="Block (S)" onCommand={onCommand}>S</TouchKey><span>Block</span></div>
            <div className="quick-control special-control"><TouchKey command="special" label="Special attack (L), requires 50 spirit" onCommand={onCommand} className={snapshot.playerEnergy >= 50 ? 'is-charged' : ''}>L</TouchKey><span>Special<Zap size={10} /></span></div>
            <button className="all-controls" onClick={() => openModal('controls')}>ALL CONTROLS<ArrowUpRight size={16} /></button>
          </div>
        </motion.div>
        <footer className="site-footer"><span>A TROUBLED PAST. AN UNFINISHED FIGHT.</span><span><Shield size={12} />NO DOWNLOADS. NO LOGIN. JUST COMBAT.</span><span>V.01 / LOCAL PLAY</span></footer>
      </main>
      {createPortal(<AnimatePresence>{modal === 'fighters' && <FightersDialog key="fighters" assets={assets} onClose={closeModal} onFight={fightFromProfile} />}{modal === 'controls' && <ControlsDialog key="controls" onClose={closeModal} onPractice={practice} />}</AnimatePresence>, overlayRoot)}
      {createPortal(<AnimatePresence>{notice && <motion.div className="toast" role="status" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss notification"><X size={14} /></button></motion.div>}</AnimatePresence>, overlayRoot)}
      <div className="sr-only" aria-live="polite">{isResult ? snapshot.winner === 'player' ? 'Kairo wins. Press Enter to continue.' : 'The Colossus wins. Press Enter to continue.' : snapshot.phase === 'paused' ? 'Game paused.' : ''}</div>
    </div>
    </MotionConfig>
  );
}